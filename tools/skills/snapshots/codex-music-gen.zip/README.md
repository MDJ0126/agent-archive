# music-gen — a Claude Code skill for generating music & audio

> Repository: <https://github.com/sirruf/music-gen-skill>

Generate music and audio **from scratch** — melodies, chord progressions, full
multi-track arrangements, sound effects, or simple tones — and get back a
playable `WAV`/`MP3` file. No cloud APIs, no model downloads: composition happens
as MIDI (where an LLM's music-theory knowledge is strongest) and is rendered to
real sampled instruments with a SoundFont using ordinary system utilities.

> **Honest framing:** this is *algorithmic composition + sampled instruments*,
> not AI text-to-music. It will not "generate a track that sounds like \<artist\>".
> For that you need a model (local MusicGen / `audiocraft`, or a cloud service
> like Suno or Replicate). This skill is fully deterministic — the same script
> always produces the same audio.

---

## What it can do

| Route | Use it for | Tooling |
|---|---|---|
| **MIDI (default)** | Melodies, chords, basslines, drums, full songs | `python3 + mido` → `fluidsynth`/`timidity` + GM SoundFont |
| **Direct synthesis** | Tones, beeps, sirens, sweeps, simple SFX | `sox` or `ffmpeg` (no SoundFont needed) |

The MIDI route gives real instrument sounds (piano, strings, bass, drums, etc.
via General MIDI program numbers). Direct synthesis is for quick non-musical
audio where a full SoundFont render would be overkill.

---

## How it works

```
your request
    │
    ▼
Claude composes a mido Python script  ──►  song.mid   (editable source)
    │                                          │
    │                                          ▼
    │                              scripts/render.sh song.mid song.wav
    │                                          │
    ▼                                          ▼
(or, for SFX)  sox / ffmpeg  ──►  tone.wav   song.wav / song.mp3   (deliverable)
```

`scripts/render.sh` auto-detects the best renderer (`fluidsynth` first, then
`timidity`), locates a GM SoundFont in the common system paths, renders at
44.1 kHz, and converts to MP3 with `ffmpeg` when the output name ends in `.mp3`.
`scripts/melody_example.py` is a working multi-track reference (piano melody +
string chords + bass + drum groove in C major) to adapt from.

---

## Requirements

- **Python 3** with the [`mido`](https://mido.readthedocs.io/) package — composing MIDI
- **`fluidsynth`** (recommended) or **`timidity`** — rendering MIDI to audio
- A **General MIDI SoundFont** (`FluidR3_GM.sf2` or `default-GM.sf2`) — the part
  people most often lack
- **`ffmpeg`** — only if you want MP3 output
- **`sox`** — only for the direct-synthesis route

Run the built-in probe at any time to see what's present:

```bash
bash scripts/render.sh --check
```

---

## Installation

### 1. Install the skill

Claude Code loads skills from `~/.claude/skills/` (user-level) or
`.claude/skills/` inside a project (project-level). Place this repo into either
location under the name `music-gen`:

```bash
# User-level (available in every project)
cp -R music-gen ~/.claude/skills/music-gen

# — or — project-level (only this project)
cp -R music-gen .claude/skills/music-gen
```

Claude Code discovers the skill via the YAML frontmatter in `SKILL.md`; no
registration step is needed. Start a new session (or `/doctor` to confirm) and
ask for music — the skill triggers automatically.

### 2. Install the toolchain

**macOS (Homebrew):**

```bash
brew install fluid-synth sox ffmpeg
pip install mido
```

You also need a GM SoundFont. A common spot the renderer checks is
`~/.local/share/soundfonts/FluidR3_GM.sf2` — download a free `FluidR3_GM.sf2`
there, or point the renderer at any `.sf2` you have:

```bash
export SOUNDFONT=/path/to/your.sf2
```

**Debian / Ubuntu:**

```bash
sudo apt install fluidsynth fluid-soundfont-gm sox ffmpeg
pip install mido
```

The `fluid-soundfont-gm` package installs the SoundFont into a path
`render.sh` already knows about.

### 3. Verify

```bash
bash scripts/render.sh --check
```

Expected (a healthy setup):

```
== music-gen toolchain check ==
  [ok]   fluidsynth
  [ok]   sox
  [ok]   ffmpeg
  [ok]   python3
  [ok]   python mido module
  [ok]   SoundFont: /…/FluidR3_GM.sf2
Render path: fluidsynth
```

Any `[MISS]` line tells you exactly what to install.

---

## Quick start (manual)

You normally just ask Claude — but the pieces work standalone too:

```bash
# Compose the reference piece and render it
python3 scripts/melody_example.py song.mid
bash   scripts/render.sh        song.mid song.wav      # → WAV
bash   scripts/render.sh        song.mid song.mp3      # → MP3 (needs ffmpeg)

# Direct synthesis, no MIDI / no SoundFont
sox -n tone.wav  synth 3 sine 440                                  # 440 Hz, 3 s
sox -n chord.wav synth 4 sine 261 sine 329 sine 392 fade 0 4 1     # Cmaj, fade out
sox -n sweep.wav synth 2 sine 200-2000                             # rising sweep
```

---

## Usage with Claude

Once installed, just describe what you want — the skill triggers on requests to
create, compose, generate, or synthesize music or sound, including MIDI,
melodies, chords, beats, a "track", a "tune", a jingle, or background music.
Examples:

- "Write me a calm 8-bar piano loop in A minor at 80 BPM."
- "Make a short upbeat jingle with bass and drums, export as MP3."
- "Generate a 2-second rising laser-zap sound effect."

Claude will compose the MIDI (or pick the synth route), render it, and hand you
the file path plus the tempo, key, and instrumentation so the result stays
editable.

---

## Repository layout

```
SKILL.md                  Skill definition + instructions Claude follows
README.md                 This file
LICENSE                   MIT license
scripts/
  render.sh               MIDI → audio renderer + environment probe (--check)
  melody_example.py       Reference multi-track mido composition
```

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `no usable MIDI renderer` | Install `fluidsynth` (preferred) or `timidity`. |
| `[MISS] SoundFont` | Install `fluid-soundfont-gm`, drop a `.sf2` in a known path, or `export SOUNDFONT=…`. |
| `[MISS] python mido module` | `pip install mido` |
| `mp3 requested but ffmpeg not installed` | `brew install ffmpeg` / `apt install ffmpeg`, or render to `.wav`. |
| Notes hang / overlap | Check note-off timing in your composition (see `add_notes` in the example). |

Run `bash scripts/render.sh --check` first whenever something fails — it reports
the exact missing piece.

---

## License

[MIT](LICENSE) © Artem Kolesnikov
